# Modern Mizunos
An addon for Mizuno's 16x, Created by Kchem and Garden Gals.
CC-BY-NC-SA-4.0
https://discord.gg/H9V6FuVGfT
https://modrinth.com/organization/garden-gals